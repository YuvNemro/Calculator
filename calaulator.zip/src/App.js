import { AppRoutes } from "./Routes";

import React from "react";

import "./styles/App.css";

function App() {

  return (
    <AppRoutes />
  )
}

export default App;
