import React, { createContext, useContext, useState } from 'react';

const GridContext = createContext();

export const GridProvider = ({ children }) => {
    let openTiles = 0;
    const [bombsLocations, setBombsLocations] = useState([]);
    const [finish, setFinish] = useState(false);
    const [victoryMessage, setVictoryMessage] = useState("");
    let rows;
    let cols;
    let bombs;



    function generateUniqueBombLocations(numBombs, numRows, numCols) {
        if (numBombs > numRows * numCols) {
            throw new Error("Number of bombs cannot exceed the total number of cells in the grid.");
        }
    
        const bombs = new Set(); // Use a Set to store unique bomb locations
        while (bombs.size < numBombs) {
            const randomRow = Math.floor(Math.random() * numRows);
            const randomCol = Math.floor(Math.random() * numCols);
            const bomb = { row: randomRow, col: randomCol };
    
            // Check if the bomb location already exists in the set
            if (!bombs.has(JSON.stringify(bomb))) {
                bombs.add(JSON.stringify(bomb)); // Add the bomb location to the set
            }
        }
    
        // Convert the set back to an array of objects
        return Array.from(bombs).map(bomb => JSON.parse(bomb));
    }
    
 
    function setBoard(numRows, numCols, numBombs) {
        setVictoryMessage("");
        rows = numRows;
        cols = numCols;
        bombs = numBombs;
        setFinish(false);
        openTiles = 0;
        let board = [];
        const newBombsLocations = generateUniqueBombLocations(numBombs, numRows, numCols);
        // console.log(newBombsLocations);
        setBombsLocations(newBombsLocations);
        let touchingBombs;

        for (let i = 0; i < numRows; i++) {
            const row = [];
            for (let j = 0; j < numCols; j++) {
                row.push({ visible: false, content: '' });
            }
            board.push(row);
        }

        board = addBombs(board, newBombsLocations);

        for (let i = 0; i < numRows; i++) {
            for (let j = 0; j < numCols; j++) {
                if (board[i][j].content !== 'bomb') {
                    touchingBombs = checkNearestBombs(board, i, j)
                    if (touchingBombs) {
                        board[i][j].content = touchingBombs;
                    }
                }
            }
        }
        return board;
    }

    function touchingFlags(board, row, col) {
        let offset = [-1, 0, 1];
        let numTouchingFlags = 0;

        for (let i = 0; i < 3; ++i) {
            for (let j = 0; j < 3; ++j) {
                let newRow = row + offset[i];
                let newCol = col + offset[j];

                // Check if the neighboring cell is within the board bounds
                if (newRow >= 0 && newRow < board.length && newCol >= 0 && newCol < board[0].length) {
                    if (board[newRow][newCol].flagged) {
                        numTouchingFlags++;
                    }
                }
            }
        }
        return numTouchingFlags;
    }

    function checkNearestBombs(board, row, col) {
        let offset = [-1, 0, 1];
        let numTouchingBombs = 0;

        for (let i = 0; i < 3; ++i) {
            for (let j = 0; j < 3; ++j) {
                let newRow = row + offset[i];
                let newCol = col + offset[j];

                if (newRow >= 0 && newRow < board.length && newCol >= 0 && newCol < board[0].length) {
                    if (board[newRow][newCol].content === 'bomb') {
                        numTouchingBombs++;
                    }
                }
            }
        }
        return numTouchingBombs;
    }

    function increment() {
        openTiles++;
    }

    function checkOpenTiles() {
        return openTiles;
    }

    function openTilesAround(board, row, col) {
        let updatedBoard = [...board];
        let offset = [-1, 0, 1];
        for (let i = 0; i < 3; ++i) {
            for (let j = 0; j < 3; ++j) {
                let newRow = row + offset[i];
                let newCol = col + offset[j];
                if (newRow >= 0 && newRow < updatedBoard.length && newCol >= 0 && newCol < updatedBoard[0].length) {
                    if (!updatedBoard[newRow][newCol].visible && !updatedBoard[newRow][newCol].flagged === true) {
                        updatedBoard=revealTile(updatedBoard, newRow, newCol);
                        // console.log(newRow + ' ' + newCol + " visible: " + updatedBoard[newRow][newCol].visible + " flagged: " + board[newRow][newCol].flagged);
                    }
                }
            }
        }
        return updatedBoard;
    }

    function revealTile(board, row, col) {
        const updatedBoard = [...board];

        switch (updatedBoard[row][col].content) {
            case '':
                revealZeroes(updatedBoard, row, col)
                openTiles--;
                break;
            case 'bomb':

                bombsLocations.forEach(array => {
                    if (!updatedBoard[array.row][array.col].flagged) {
                        updatedBoard[array.row][array.col].visible = true;
                    }
                });
                changeBomb(updatedBoard, row, col);
                setFinish(true);
                break;

            default:
                break;
        }
        increment();

        updatedBoard[row][col].visible = true;

        if (checkOpenTiles() === ((rows * cols) - bombs)) {
            setFlagsAtBombs(updatedBoard);
            setVictoryMessage("victory!")
        }

        return updatedBoard;
    }

    function revealZeroes(board, row, col) {
        const updatedBoard = [...board];
        const numRows = board.length;
        const numCols = board[0].length;
        if (row < 0 || row >= numRows || col < 0 || col >= numCols) {
            return;
        }
        const cell = updatedBoard[row][col];
        if (cell.visible) {
            return;
        }
        if (cell.content !== '') {
            if (cell.content !== 'bomb') {
                revealTile(updatedBoard, row, col);
            }
            return;
        }
        cell.visible = true;
        increment();
        revealZeroes(board, row - 1, col - 1);
        revealZeroes(board, row - 1, col);
        revealZeroes(board, row - 1, col + 1);
        revealZeroes(board, row, col - 1);
        revealZeroes(board, row, col + 1);
        revealZeroes(board, row + 1, col - 1);
        revealZeroes(board, row + 1, col);
        revealZeroes(board, row + 1, col + 1);


        return updatedBoard;
    }


    function addBombs(board, bombsLocations) {
        const updatedBoard = [...board];

        bombsLocations.forEach(array => {
            updatedBoard[array.row][array.col].content = 'bomb';
        });

        return updatedBoard;
    }

    function changeBomb(board, row, col) {
        const updatedBoard = [...board];
        updatedBoard[row][col].content = 'firstBomb';

        return updatedBoard;
    }

    function getBombsLocations() {
        return bombsLocations;
    }
    function setFlagsAtBombs(board) {
        const updatedBoard = [...board];
        bombsLocations.forEach(arr => {
            updatedBoard[arr.row][arr.col].flagged = true;
        })
    }

    function getCellClassName(content) {
        switch (content) {
            case 'bomb':
                return 'bomb-cell';
            case '':
                return 'zero-cell';
            case 1:
                return 'one-cell';
            case 2:
                return 'two-cell';
            case 3:
                return 'three-cell';
            case 4:
                return 'four-cell';
            case 5:
                return 'five-cell';
            case 6:
                return 'siz-cell';
            case 7:
                return 'seven-cell';
            case 8:
                return 'eight-cell';
            default:
                return '';
        }
    }


    return (
        <GridContext.Provider value={{ setBoard, addBombs, revealTile, getCellClassName, getBombsLocations, changeBomb, checkOpenTiles, setFlagsAtBombs, touchingFlags, openTilesAround, finish, victoryMessage }}>
            {children}
        </GridContext.Provider>
    );
};
export const useGridProvider = () => useContext(GridContext);