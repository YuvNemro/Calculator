import './App.css';
import React from 'react';
import { BrowserRouter as Router ,Link } from 'react-router-dom';
import MinesRoutes from './MinesRoutes';

function App() {
  return (
    <Router>
      <div>
        <MinesRoutes />
      </div>
    </Router>
  );
}

export default App;
