import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useGridProvider } from "./Grid"
import "./Login.css";

const Login = () => {
    const navigate = useNavigate();
    const { setBoard } = useGridProvider();
    const [rows, setNumRows] = useState(8);
    const [cols, setNumCols] = useState(8);
    const [bombs, setNumBombs] = useState(10);
    const [errorMessage1, setErrorMessage1] = useState("");
    const [errorMessage2, setErrorMessage2] = useState("");
    const [errorMessage3, setErrorMessage3] = useState("");
    const [errorMessage4, setErrorMessage4] = useState("");
    let board;


    const makeGridAndStart = () => {
        setInputs();
        if (checkInputs()) {
            board = setBoard(rows, cols, bombs);
            navigate("/Grid2", { state: { board, bombs, rows, cols } }); // Pass 'board' as state
        }
    };

    function setInputs() {
        setErrorMessage1("");
        setErrorMessage2("");
        setErrorMessage3("");
        setErrorMessage4("");
    }

    function checkInputs() {
        let check = 1;
        if (rows <= 0 || rows > 25) {
            setErrorMessage1("num of rows must be between 0-25");
            check = 0;
        }
        if (cols <= 0 || cols > 25) {
            setErrorMessage2("num of cols must be between 0-25");
            check = 0;
        }
        if (rows * cols <= bombs) {
            setErrorMessage3("num of bombs must be less than " + rows * cols);
            check = 0;
        }
        if (bombs <= 0) {
            setErrorMessage4("num of bombs must be greater than 0");
            check = 0;
        }
        return true & check;
    }


    const handleNumRowsChange = (e) => {
        const value = e.target.value.trim(); // Remove leading and trailing whitespace
        if (value !== '' && !isNaN(value) && Number.isInteger(parseFloat(value))) {
            setNumRows(parseInt(value));
        } else {
            setErrorMessage1("num of rows musdfgb");
        }
    };


    const handleNumColsChange = (e) => {
        setNumCols(parseInt(e.target.value));
    };

    const handleNumBombsChange = (e) => {
        setNumBombs(parseInt(e.target.value));

    };

    return (
        <div className="loginContainer">
            <h1>login</h1>
            <button onClick={makeGridAndStart}>Start</button>
            <label htmlFor="numBombs">Rows:
                <input type="number" id="numRows" value={rows} onChange={handleNumRowsChange} />
            </label>
            <label htmlFor="numBombs">Cols:
                <input type="number" id="numCols" value={cols} onChange={handleNumColsChange} />
            </label>
            <label htmlFor="numBombs">Bombs:
                <input type="number" id="numBombs" value={bombs} onChange={handleNumBombsChange} />
            </label>
            {errorMessage1 && <p className="error-message">{errorMessage1}</p>}
            {errorMessage2 && <p className="error-message">{errorMessage2}</p>}
            {errorMessage3 && <p className="error-message">{errorMessage3}</p>}
            {errorMessage4 && <p className="error-message">{errorMessage4}</p>}
        </div>
    );
};

export default Login;
