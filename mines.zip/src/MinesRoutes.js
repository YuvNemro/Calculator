import { Routes, Route } from 'react-router-dom';
import Login from './Login';
import GridComponent from './Grid2';
import { GridProvider } from './Grid';

const MinesRoutes = () => {
    return (
        <div>
            <GridProvider>
                <Routes>
                    <Route path="/" element={<Login />} />
                    {/* <Route path="/Game" element={<Game />} /> */}
                    <Route path="/Grid2" element={<GridComponent />} />
                </Routes>
            </GridProvider>
        </div>
    );
}

export default MinesRoutes;
