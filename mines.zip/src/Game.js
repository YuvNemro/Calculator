// import React from "react";
// import { useLocation, Link, useNavigate } from "react-router-dom";
// import "./Grid.css"; // Import CSS file for styling

// const Game = () => {
//     const navigate = useNavigate();
//     const location = useLocation();
//     const { grid } = location.state; // Access the grid state from location state

//     const navigateHome = () => {
//         navigate("/");
//     };

//     return (
//         <div>
//             <button onClick={navigateHome}>Go to Login Page</button>
//             <div className="grid-container">
//                 {/* Render the grid based on the grid state */}
//                 {grid.map((row, rowIndex) => (
//                     <div key={rowIndex} className="grid-row">
//                         {row.map((cell, colIndex) => (
//                             <div key={`${rowIndex}-${colIndex}`} className={`grid-cell ${cell.visible ? 'revealed' : ''}`}>
//                                 {/* Render the content of each cell */}
//                                 {cell.content}
//                             </div>
//                         ))}
//                     </div>
//                 ))}
//             </div>
//         </div>
//     );
// };

// export default Game;
