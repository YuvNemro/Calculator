import React, { useEffect, useState, useCallback } from 'react';
import bombImage from './bomb.png';
import firstBomb from './redBomb.png';
import flag from './flag.png';
import { Link, useLocation } from 'react-router-dom';
import { useGridProvider } from './Grid';
import './Grid.css';

const GridComponent = () => {
    const location = useLocation();
    let { board } = location.state;
    let { bombs } = location.state;
    let { rows } = location.state;
    let { cols } = location.state;
    const { revealTile, setBoard, getCellClassName, touchingFlags, 
            openTilesAround,finish,victoryMessage } = useGridProvider();
    const [currBoard, setCurrBoard] = useState(board);
    
    // Wrap handle functions with useCallback
    const handleDoubleClick = useCallback((rowIndex, colIndex) => {
        let updatedBoard = [...currBoard];
        if (currBoard[rowIndex][colIndex].content === touchingFlags(updatedBoard, rowIndex, colIndex)) {
            // console.log('doubleclick ' + rowIndex +' '+colIndex);
            updatedBoard=openTilesAround(updatedBoard, rowIndex, colIndex)
            setCurrBoard([...updatedBoard]);
        }
    }, [currBoard, touchingFlags, openTilesAround]);

    const handleRightClick = useCallback((rowIndex, colIndex) => {
        const updatedBoard = [...currBoard]; 
        updatedBoard[rowIndex][colIndex].flagged = !updatedBoard[rowIndex][colIndex].flagged;
        setCurrBoard([...updatedBoard]);
    }, [currBoard, setCurrBoard]);

    const handleClick = useCallback((rowIndex, colIndex) => {
        const updatedBoard = [...currBoard]; 
        setCurrBoard(revealTile([...updatedBoard], rowIndex, colIndex));
    }, [currBoard, setCurrBoard, revealTile]);

    function reset() {
        setCurrBoard(setBoard(rows, cols, bombs));
    }
    
    // useEffect hook
    useEffect(() => {
        console.log('handle functions changed');
    }, [handleDoubleClick, handleRightClick, handleClick]);

    return (
        <div>
            <Link to="/"> Back To Login </Link>
            <br />
            <button onClick={reset}>reset</button>
            <div className="grid-container">
                <div className="grid">
                    {currBoard.map((row, rowIndex) => (
                        <div key={rowIndex} className="grid-row">
                            {row.map((cell, colIndex) => (
                                <button
                                    key={`${rowIndex}-${colIndex}`}
                                    className={`grid-button ${cell.visible ? getCellClassName(cell.content) : ''} `}
                                    onClick={() => {
                                        if (!cell.visible && !finish && !cell.flagged) {
                                            handleClick(rowIndex, colIndex);
                                        }
                                    }}
                                    onContextMenu={(event) => {
                                        event.preventDefault();
                                        if (!cell.visible && !finish) {
                                            handleRightClick(rowIndex, colIndex);
                                        }
                                    }}
                                    onDoubleClick={() => {
                                        if (cell.visible && !finish) {
                                            handleDoubleClick(rowIndex, colIndex);
                                        }
                                    }}
                                >
                                    {cell.visible && cell.content === 'bomb' && <img src={bombImage} alt='Bomb' className="bomb-image" />}
                                    {cell.visible && cell.content === 'firstBomb' && <img src={firstBomb} alt='Bomb' className="redBomb-image" />}
                                    {cell.visible && cell.content !== 'bomb' && cell.content !== 'firstBomb' && cell.content}
                                    {cell.flagged && <img src={flag} alt='Flag' className="flag-image" />}

                                </button>
                            ))}
                        </div>
                    ))}
                </div>
                {victoryMessage && <p className="victory-message">{victoryMessage}</p>}
            </div>

        </div>
    );
};

export default GridComponent;
